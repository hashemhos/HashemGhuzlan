package com.madfooat.billinquiry.exceptions;

public class InvalidBillInquiryResponse extends RuntimeException {
}
